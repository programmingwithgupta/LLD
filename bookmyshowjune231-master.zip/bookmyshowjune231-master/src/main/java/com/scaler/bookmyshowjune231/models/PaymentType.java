package com.scaler.bookmyshowjune231.models;

public enum PaymentType {
    COUPON,
    MONEY,
    REFUND,
    DISCOUNT,
}
