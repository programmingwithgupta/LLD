package com.scaler.bookmyshowjune231.exceptions;

public class SeatNotAvailableException extends Exception {
}
