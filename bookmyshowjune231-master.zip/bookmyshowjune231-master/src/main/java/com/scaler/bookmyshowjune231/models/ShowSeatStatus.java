package com.scaler.bookmyshowjune231.models;

public enum ShowSeatStatus {
    AVAILABLE,
    BOOKED,
    LOCKED,
}
