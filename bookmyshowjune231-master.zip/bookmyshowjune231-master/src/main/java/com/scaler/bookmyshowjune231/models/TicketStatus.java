package com.scaler.bookmyshowjune231.models;

public enum TicketStatus {
    BOOKED,
    PROCESSING,
    CANCELLED,
}
