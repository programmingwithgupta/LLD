package com.scaler.bookmyshowjune231.models;

public enum Feature {
    TWO_D,
    DOLBY_AUDIO,
    THREE_D,
}
