package com.scaler.bookmyshowjune231.exceptions;

public class InvalidArgumentsException extends Exception {

    public InvalidArgumentsException(String message) {
        super(message);
    }
}
