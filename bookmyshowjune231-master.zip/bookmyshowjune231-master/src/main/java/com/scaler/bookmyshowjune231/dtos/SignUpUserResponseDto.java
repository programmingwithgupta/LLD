package com.scaler.bookmyshowjune231.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignUpUserResponseDto {
    private Long userId;
}
