package com.scaler.bookmyshowjune231;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bookmyshowjune231ApplicationTests {

    @Test
    void contextLoads() {
    }

}
