# Booking a Ticket

```markdown

/book -> BookingController

/ticket -> TicketController
```